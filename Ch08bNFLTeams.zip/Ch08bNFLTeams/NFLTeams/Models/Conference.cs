﻿namespace NFLTeams.Models
{
    public class Conference
    {
        public string ConferenceID { get; set; }
        public string Name { get; set; }
    }
}
