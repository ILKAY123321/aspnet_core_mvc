﻿namespace NFLTeams.Models
{
    public static class Utility
    {
        public static void LogTeamClick(string teamID)
        {
            // code to log click in database, log file, or other data store
        }
    }
}
