﻿namespace NFLTeams.Models
{
    public class Division
    {
        public string DivisionID { get; set; }
        public string Name { get; set; }
    }
}
