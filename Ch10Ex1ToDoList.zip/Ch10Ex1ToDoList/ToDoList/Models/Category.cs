﻿namespace ToDoList.Models
{
    public class Category
    {
        public string CategoryId { get; set; }
        public string Name { get; set; }
    }
}
